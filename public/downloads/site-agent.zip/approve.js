"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // src/theme.ts
  var require_theme = __commonJS({
    "src/theme.ts"() {
      "use strict";
      var THEME_KEY = "chatbotTheme";
      var applyTheme = (value) => {
        document.documentElement.dataset.theme = value === "light" ? "light" : "dark";
      };
      var initial = new URLSearchParams(location.search).get("theme");
      applyTheme(initial);
      var themeChanged = false;
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes[THEME_KEY]) {
          themeChanged = true;
          applyTheme(changes[THEME_KEY].newValue);
        }
      });
      chrome.storage.local.get(THEME_KEY).then((saved) => {
        if (!themeChanged && saved[THEME_KEY]) applyTheme(saved[THEME_KEY]);
      }).catch(() => {
      });
    }
  });

  // src/approve.ts
  var require_approve = __commonJS({
    "src/approve.ts"() {
      var import_theme = __toESM(require_theme());
      var p = new URLSearchParams(location.search);
      var id = p.get("id") ?? "";
      var mode = p.get("mode") ?? "action";
      var $ = (s) => document.getElementById(s);
      var ok = $("ok");
      if (mode === "connect") {
        $("title").textContent = "Allow this site to use Site Agent?";
        $("detail").textContent = p.get("origin") ?? "";
        ok.textContent = "Allow";
        $("description").textContent = "Connect this site to the tools in your browser.";
      } else if (mode === "permission") {
        $("title").textContent = "Allow the assistant to use this site?";
        $("detail").textContent = p.get("origin") ?? "";
        ok.textContent = "Allow";
        $("description").textContent = "Grant browser access to this site to continue the requested action.";
      } else {
        $("title").textContent = "Approve this action?";
        $("detail").textContent = `${p.get("tool")}

${p.get("preview") ?? ""}`;
      }
      var send = (approved) => chrome.runtime.sendMessage({ type: "APPROVAL_RESULT", id, approved });
      var no = $("no");
      async function respond(allow) {
        if (ok.disabled) return;
        ok.disabled = no.disabled = true;
        $("error").textContent = "";
        try {
          let approved = allow;
          if (allow && mode === "permission") {
            approved = await chrome.permissions.request({ origins: [`${p.get("origin")}/*`] });
          }
          await send(approved);
        } catch {
          $("error").textContent = "The request could not be completed. Close this window and retry from Chatbot.";
          ok.disabled = no.disabled = false;
        }
      }
      ok.onclick = () => respond(true);
      no.onclick = () => respond(false);
      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") void respond(false);
      });
    }
  });
  require_approve();
})();
