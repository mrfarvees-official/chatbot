"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // src/theme.ts
  var require_theme = __commonJS({
    "src/theme.ts"() {
      "use strict";
      var THEME_KEY = "chatbotTheme";
      var applyTheme = (value) => {
        document.documentElement.dataset.theme = value === "light" ? "light" : "dark";
      };
      var initial = new URLSearchParams(location.search).get("theme");
      applyTheme(initial);
      var themeChanged = false;
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes[THEME_KEY]) {
          themeChanged = true;
          applyTheme(changes[THEME_KEY].newValue);
        }
      });
      chrome.storage.local.get(THEME_KEY).then((saved) => {
        if (!themeChanged && saved[THEME_KEY]) applyTheme(saved[THEME_KEY]);
      }).catch(() => {
      });
    }
  });

  // src/console.ts
  var require_console = __commonJS({
    "src/console.ts"() {
      var import_theme = __toESM(require_theme());
      var $ = (id) => document.getElementById(id);
      var call = (type, extra = {}) => chrome.runtime.sendMessage({ type, ...extra });
      var outputs = /* @__PURE__ */ new Map();
      var toolsKey = "";
      function el(tag, props = {}, ...kids) {
        const e = document.createElement(tag);
        Object.assign(e, props);
        e.append(...kids);
        return e;
      }
      function field(name, schema, required) {
        let input;
        if (schema.enum) {
          const s = el("select");
          schema.enum.forEach(
            (v) => s.append(el("option", { value: v, textContent: v }))
          );
          input = s;
        } else if (schema.type === "boolean")
          input = el("input", { type: "checkbox" });
        else if (schema.type === "number") input = el("input", { type: "number" });
        else if (name === "body" || name === "text")
          input = el("textarea", { rows: 4 });
        else input = el("input", { type: "text" });
        const get = () => {
          if (input instanceof HTMLInputElement && input.type === "checkbox")
            return input.checked;
          if (input.value === "") return void 0;
          return schema.type === "number" ? Number(input.value) : input.value;
        };
        return {
          node: el("label", {}, `${name}${required ? " *" : ""}`, input),
          get
        };
      }
      function toolCard(t, disabled) {
        const props = t.inputSchema?.properties ?? {};
        const req = t.inputSchema?.required ?? [];
        const fields = Object.entries(props).map(([n, s]) => ({
          n,
          ...field(n, s, req.includes(n))
        }));
        const out = el("pre", { textContent: outputs.get(t.name) ?? "" });
        const run = el("button", { textContent: "Run" });
        run.onclick = async () => {
          const args = {};
          for (const f of fields) {
            const v = f.get();
            if (v !== void 0) args[f.n] = v;
          }
          out.textContent = "running...";
          const text = JSON.stringify(
            await call("AGENT_CALL_TOOL", { name: t.name, args }),
            null,
            2
          );
          outputs.set(t.name, text);
          out.textContent = text;
          renderLog();
          renderPerms();
          renderTools();
        };
        const enabled = el("input", {
          type: "checkbox",
          checked: !disabled.includes(t.name)
        });
        enabled.onchange = async () => {
          const { disabledTools = [] } = await chrome.storage.local.get("disabledTools");
          const disabled2 = disabledTools;
          const next = enabled.checked ? disabled2.filter((n) => n !== t.name) : [...disabled2, t.name];
          await chrome.storage.local.set({ disabledTools: next });
        };
        return el(
          "div",
          { className: "card" },
          el("b", {}, t.name),
          el("span", { className: "badge", textContent: t.risk }),
          el("label", {}, enabled, " enabled"),
          el("div", { textContent: t.description }),
          ...fields.map((f) => f.node),
          run,
          out
        );
      }
      async function renderTools() {
        const tools = await call("AGENT_LIST_TOOLS", { all: true });
        const { disabledTools = [] } = await chrome.storage.local.get("disabledTools");
        const key = tools.map((t) => t.name).join(",");
        if (key === toolsKey) return;
        toolsKey = key;
        $("tools").replaceChildren(
          ...tools.map((t) => toolCard(t, disabledTools))
        );
      }
      async function renderPerms() {
        const required = new Set(chrome.runtime.getManifest().host_permissions ?? []);
        const { origins = [] } = await chrome.permissions.getAll();
        $("perms").replaceChildren(
          ...origins.filter((o) => !required.has(o)).map((o) => {
            const b = el("button", { textContent: "Revoke" });
            b.onclick = async () => {
              await chrome.permissions.remove({ origins: [o] });
              renderPerms();
            };
            return el("div", {}, o + " ", b);
          })
        );
      }
      async function renderConnections() {
        const { connectedOrigins = [] } = await chrome.storage.local.get("connectedOrigins");
        $("connectedSites").replaceChildren(
          ...connectedOrigins.map((origin) => {
            const revoke = el("button", { textContent: "Revoke" });
            revoke.onclick = async () => {
              const current = await chrome.storage.local.get("connectedOrigins");
              await chrome.storage.local.set({
                connectedOrigins: (current.connectedOrigins ?? []).filter((item) => item !== origin)
              });
              renderConnections();
            };
            return el("div", {}, origin + " ", revoke);
          })
        );
      }
      async function renderLog() {
        const { log = [] } = await chrome.storage.local.get("log");
        $("log").textContent = log.slice(-50).reverse().map(
          (e) => `${new Date(e.t).toLocaleTimeString()}  ${e.source}  ${e.tool}  -> ${e.outcome}`
        ).join("\n");
      }
      var paused = $("paused");
      chrome.storage.local.get("paused").then((s) => paused.checked = !!s.paused);
      paused.onchange = () => chrome.storage.local.set({ paused: paused.checked });
      renderTools();
      renderPerms();
      renderConnections();
      renderLog();
    }
  });
  require_console();
})();
